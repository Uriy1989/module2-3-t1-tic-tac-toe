import { initialState } from './initialState';

export const reducer = (state = initialState, action) => {
	const { type, payload } = action;

	// const newField = [...field];
	// newField[index] = currentPlayer;

	// dispatch(setFiled(newField));
	// return newField;

	switch (type) {
		case 'SET_FIELD': {
			const newField = [...state.field];
			newField[state.currentIndex] = state.currentPlayer;
			return {
				...state,
				field: newField,
			};
		}
		case 'SET_CURRENT_PLAYER': {
			return {
				...state,
				currentPlayer: state.currentPlayer === 'X' ? 'O' : 'X',
			};
		}
		case 'SET_IS_GAME_ENDED': {
			return {
				...state,
				isGameEnded: payload,
			};
		}
		case 'SET_IS_DRAW': {
			return {
				...state,
				isDraw: payload,
			};
		}
		case 'RESTART_GAME': {
			return initialState;
		}
		case 'SET_CURRENT_INDEX': {
			return {
				...state,
				currentIndex: payload,
			};
		}

		default:
			return state;
	}
};
